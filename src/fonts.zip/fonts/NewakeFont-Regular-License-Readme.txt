
NEWAKE FONT
by Indieground Design © 2021.
V.2.1


_____________________________________________________________________________


This is a license for commercial use, sales, and distribution of designs and documents which are created using the font. This may include printed materials, logos, and rendered content like photographs, film, video and bitmap graphics.
If distributed, the design should not contain the original font, but can be converted to vector outlines, rasterized, or subsetted and embedded in an electronic document like a PDF or eBook.

For any doubt or question contact us at info@indieground.net

_____________________________________________________________________________


info@indieground.net
https://indieground.net

